﻿using FakeItEasy;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Prime.RushHour.Tests
{
    public class AuthenticationServiceTest
    {
        [Fact]
        public async void AuthenticateAccountAsync_Email_Not_Exist_ExceptionThrown() 
        {
            //Arrange
            var accountRepository = A.Fake<IAccountRepository>();
            var email = "mail@email.com";
            var password = "Kabriooo123?";

            AccountDto? returnValue = null;
            A.CallTo(() => accountRepository.GetAccountWithEmailAsync(email)).Returns(Task.FromResult(returnValue));

            var jwtSettings = new JwtSettings();
            var authenticationService = new AuthenticationService(accountRepository,jwtSettings);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => authenticationService.AuthenticateAccountAsync(email,password));
        }
    }
}
