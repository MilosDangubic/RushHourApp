﻿using FakeItEasy;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Prime.RushHour.Tests
{
    public class ProviderServiceTest
    {
        private readonly IProviderRepository _providerRepository = A.Fake<IProviderRepository>();

        [Fact]
        public async Task DeleteAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            ProviderDto providerDto = new ProviderDto();
            providerDto.Id = Guid.NewGuid();

            var id = Guid.NewGuid();

            A.CallTo(() => _providerRepository.DeleteAsync(id)).Returns(Task.FromResult(false));

            var providerService = new ProviderService(_providerRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => providerService.DeleteAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            var id = Guid.NewGuid();
            ProviderDto? providerDto = null;

            A.CallTo(() => _providerRepository.GetByIdAsync<ProviderDto?>(id)).Returns(Task.FromResult(providerDto));

            var providerService = new ProviderService(_providerRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => providerService.GetByIdAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Exist_Returns_Provider()
        {
            //Arrange
            var id = Guid.NewGuid();
            ProviderDto provider = new ProviderDto();
            provider.Id = Guid.NewGuid();

            A.CallTo(() => _providerRepository.GetByIdAsync<ProviderDto>(id)).Returns(Task.FromResult(provider));

            var providerService = new ProviderService(_providerRepository);

            //Act   
            var returnValue = await providerService.GetByIdAsync(id);

            //Assert
            Assert.Equal(provider.Id, returnValue.Id);
        }
    }
}
