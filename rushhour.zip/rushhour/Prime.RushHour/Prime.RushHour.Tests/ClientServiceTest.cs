﻿using FakeItEasy;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Prime.RushHour.Tests
{
    public class ClientServiceTest
    {
        private readonly IClientRepository _clientRepository = A.Fake<IClientRepository>();

        [Fact]
        public async Task DeleteAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            ClientDto clientDto = new ClientDto();
            clientDto.Id = Guid.NewGuid();

            var id = Guid.NewGuid();

            A.CallTo(() => _clientRepository.DeleteAsync(id)).Returns(Task.FromResult(false));

            var clientService = new ClientService(_clientRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => clientService.DeleteAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            var id = Guid.NewGuid();
            ClientDto? clientDto = null;

            A.CallTo(() => _clientRepository.GetByIdAsync<ClientDto?>(id)).Returns(Task.FromResult(clientDto));

            var clientService = new ClientService(_clientRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => clientService.GetByIdAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Exist_Returns_Provider()
        {
            //Arrange
            var id = Guid.NewGuid();
            ClientDto client = new ClientDto();
            client.Id = Guid.NewGuid();

            A.CallTo(() => _clientRepository.GetByIdAsync<ClientDto>(id)).Returns(Task.FromResult(client));

            var clientService = new ClientService(_clientRepository);

            //Act   
            var returnValue = await clientService.GetByIdAsync(id);

            //Assert
            Assert.Equal(client.Id, returnValue.Id);
        }
    }
}
