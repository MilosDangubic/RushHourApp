using FakeItEasy;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Prime.RushHour.Tests
{
    public class AccountServiceTest
    {
        private readonly IAccountRepository _accountRepository = A.Fake<IAccountRepository>();

        [Fact]
        public async void GetAccountWithEmailAsync_Returns_The_Correct_Account()
        {
            //Arrange
            var email = "testmail@gmail.com";
            var accountDto = new AccountDto();
            accountDto.Email = email;
            accountDto.Id = Guid.NewGuid();

            A.CallTo(() => _accountRepository.GetAccountWithEmailAsync(email)).Returns(Task.FromResult(accountDto));

            var accountService = new AccountService(_accountRepository);

            //Act
            var result = await accountService.GetAccountWithEmailAsync(email);

            //Assert
            Assert.Equal(result.Id, accountDto.Id);
            Assert.Equal(result.Email, email);
        }

        [Fact]
        public async Task RegisterAsync_ExistingEmail_ExceptionThrown()
        {
            //Arrange
            AccountDto accountDto = new AccountDto();
            accountDto.Password = "Kabriooo123?";

            A.CallTo(() => _accountRepository.GetAccountWithEmailAsync(accountDto.Email)).Returns(Task.FromResult(accountDto));
            var accountService = new AccountService(_accountRepository);

            //Act & Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => accountService.RegisterAsync(accountDto));
        }

        [Fact]
        public async Task UpdateEmail_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            AccountDto accountDto = new AccountDto();
            accountDto.Id = Guid.NewGuid();

            var email = "email@gmail.com";
            var id = Guid.NewGuid();

            AccountDto? returnValue = null;
            A.CallTo(() => _accountRepository.GetByIdAsync<AccountDto?>(id)).Returns(Task.FromResult(returnValue));

            var accountService = new AccountService(_accountRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => accountService.UpdateEmail(id, email));
        }

        [Fact]
        public async Task UpdateEmail_Email_Taken_ExceptionThrown()
        {
            //Arrange
            AccountDto accountDto = new AccountDto();
            accountDto.Id = Guid.NewGuid();

            var email = "email@gmail.com";
            var id = Guid.NewGuid();

            AccountDto exitsingEmailAccount = new AccountDto();
            exitsingEmailAccount.Email = email;

            A.CallTo(() => _accountRepository.GetByIdAsync<AccountDto>(id)).Returns(Task.FromResult(accountDto));
            A.CallTo(() => _accountRepository.GetAccountWithEmailAsync(email)).Returns(Task.FromResult(exitsingEmailAccount));

            var accountService = new AccountService(_accountRepository);

            //Act && Assert
            await Assert.ThrowsAsync<ArgumentException>(() => accountService.UpdateEmail(id, email));
        }

        [Fact]
        public async Task UpdatePassword_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            AccountDto accountDto = new AccountDto();
            accountDto.Id = Guid.NewGuid();

            var oldPassword = "Kabriooo123?";
            var newPaswword = "123Kabriooo?";
            var id = Guid.NewGuid();

            AccountDto? returnValue = null;
            A.CallTo(() => _accountRepository.GetByIdAsync<AccountDto?>(id)).Returns(Task.FromResult(returnValue));

            var accountService = new AccountService(_accountRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => accountService.UpdatePassword(id, oldPassword, newPaswword));
        }

        [Fact]
        public async Task DeleteAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            AccountDto accountDto = new AccountDto();
            accountDto.Id = Guid.NewGuid();

            var id = Guid.NewGuid();

            A.CallTo(() => _accountRepository.DeleteAsync(id)).Returns(Task.FromResult(false));

            var accountService = new AccountService(_accountRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => accountService.DeleteAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            var id = Guid.NewGuid();
            AccountDto? returnValue = null;

            A.CallTo(() => _accountRepository.GetByIdAsync<AccountDto?>(id)).Returns(Task.FromResult(returnValue));

            var accountService = new AccountService(_accountRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => accountService.GetByIdAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Exist_Returns_Account()
        {
            //Arrange
            var id = Guid.NewGuid();
            AccountDto account = new AccountDto();
            account.Id = Guid.NewGuid();

            A.CallTo(() => _accountRepository.GetByIdAsync<AccountDto>(id)).Returns(Task.FromResult(account));

            var accountService = new AccountService(_accountRepository);

            //Act   
            var returnValue = await accountService.GetByIdAsync(id);

            //Assert
            Assert.Equal(account.Id, returnValue.Id);
        }
    }
}