﻿using FakeItEasy;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Prime.RushHour.Tests
{
    public class EmployeeServiceTest
    {
        private readonly IEmployeeRepository _emoployeeRepository= A.Fake<IEmployeeRepository>();

        [Fact]
        public async Task DeleteAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            EmployeeDto employeeDto = new EmployeeDto();
            employeeDto.Id = Guid.NewGuid();

            var id = Guid.NewGuid();

            A.CallTo(() => _emoployeeRepository.DeleteAsync(id)).Returns(Task.FromResult(false));

            var employeeService = new EmployeeService(_emoployeeRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => employeeService.DeleteAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Not_Exist_ExceptionThrown()
        {
            //Arrange
            var id = Guid.NewGuid();
            EmployeeDto? employeeDto = null;

            A.CallTo(() => _emoployeeRepository.GetByIdAsync<EmployeeDto?>(id)).Returns(Task.FromResult(employeeDto));

            var employeeService = new EmployeeService(_emoployeeRepository);

            //Act && Assert
            await Assert.ThrowsAsync<KeyNotFoundException>(() => employeeService.GetByIdAsync(id));
        }

        [Fact]
        public async void GetByIdAsync_Id_Exist_Returns_Provider()
        {
            //Arrange
            var id = Guid.NewGuid();
            EmployeeDto employee = new EmployeeDto();
            employee.Id = Guid.NewGuid();

            A.CallTo(() => _emoployeeRepository.GetByIdAsync<EmployeeDto>(id)).Returns(Task.FromResult(employee));

            var employeeService = new EmployeeService(_emoployeeRepository);

            //Act   
            var returnValue = await employeeService.GetByIdAsync(id);

            //Assert
            Assert.Equal(employee.Id, returnValue.Id);
        }
    }
}
