﻿using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Prime.RushHour.Services.Services
{
    public class AccountService : BaseService<AccountDto>, IAccountService
    {
        private readonly IAccountRepository _accountRepository;

        public AccountService(IAccountRepository accountRepository) : base(accountRepository)
        {
            _accountRepository = accountRepository;
        }

        public async Task<AccountDto> GetAccountWithEmailAsync(string email)
        {
            return await _accountRepository.GetAccountWithEmailAsync(email);
        }

        public async Task RegisterAsync(AccountDto accountDto)
        {
            accountDto.Password = BCrypt.Net.BCrypt.HashPassword(accountDto.Password);

            AccountDto account = await _accountRepository.GetAccountWithEmailAsync(accountDto.Email);
            if (account != null)
            {
                throw new KeyNotFoundException();
            }

            await _accountRepository.CreateAsync(accountDto);
        }

        public async Task UpdateEmail(Guid id, string email)
        {
            AccountDto accountDto = await _accountRepository.GetByIdAsync<AccountDto>(id);
            if (accountDto == null)
            {
                throw new KeyNotFoundException();
            }

            accountDto = await _accountRepository.GetAccountWithEmailAsync(email);
            if (accountDto != null)
            {
                throw new ArgumentException();
            }

            await _accountRepository.UpdateEmail(id, email);
        }

        public async Task UpdatePassword(Guid id, string oldPassword, string newPassword)
        {
            AccountDto accountDto = await _accountRepository.GetByIdAsync<AccountDto>(id);
            if (accountDto == null)
            {
                throw new KeyNotFoundException();
            }

            if (!BCrypt.Net.BCrypt.Verify(oldPassword, accountDto.Password))
            {
                throw new ArgumentException();
            }

            newPassword = BCrypt.Net.BCrypt.HashPassword(newPassword);

            if (!await _accountRepository.UpdatePassword(id, newPassword))
            {
                throw new ArgumentException();
            }
        }
    }
}
