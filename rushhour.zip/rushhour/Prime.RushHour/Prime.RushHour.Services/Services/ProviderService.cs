﻿using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Services.Services
{
    public class ProviderService : BaseService<ProviderDto>, IProviderService
    {
        private readonly IProviderRepository _providerRepository;

        public ProviderService(IProviderRepository providerRepository) : base(providerRepository)
        {
            _providerRepository = providerRepository;
        }
    }
}
