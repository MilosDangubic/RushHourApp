﻿using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Services.Services
{
    public class BaseService<TDto> : IBaseService<TDto> where TDto : BaseDto
    {
        protected readonly IBaseRepository _baseRepository;

        public BaseService(IBaseRepository baseRepository)
        {
            _baseRepository = baseRepository;
        }

        public async Task CreateAsync(TDto tDto)
        {
            await _baseRepository.CreateAsync<TDto>(tDto);
        }

        public async Task DeleteAsync(Guid id)
        {
            bool deleted = await _baseRepository.DeleteAsync(id);
            if (!deleted)
            {
                throw new KeyNotFoundException();
            }
        }

        public async Task<IEnumerable<TDto>> GetAllAsync(int? pageNumber, int? pageSize)
        {
            pageSize = (pageSize == null) ? 3 : pageSize;
            pageSize = (pageSize > 30) ? 30 : pageSize;

            return await _baseRepository.GetAllAsync<TDto>(pageNumber ?? 1, (int)pageSize);
        }

        public async Task<TDto> GetByIdAsync(Guid id)
        {
            TDto tDto = await _baseRepository.GetByIdAsync<TDto>(id);
            if (tDto == null)
            {
                throw new KeyNotFoundException();
            }

            return tDto;
        }

        public async Task UpdateAsync(Guid id, TDto tDto)
        {
            tDto.Id = id;
            await _baseRepository.UpdateAsync<TDto>(tDto);
        }
    }
}
