﻿using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Services.Services
{
    public class ClientService : BaseService<ClientDto>, IClientService
    {
        private readonly IClientRepository _clientRepository;

        public ClientService(IClientRepository clientRepository) : base(clientRepository)
        {
            _clientRepository = clientRepository;
        }
    }
}
