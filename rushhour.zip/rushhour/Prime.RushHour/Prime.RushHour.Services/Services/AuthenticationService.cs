﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Services.Services
{
    public class AuthenticationService : BaseService<AccountDto>, IAuthenticationService
    {
        private readonly JwtSettings _jwtSettings;
        private IAccountRepository _accountRepository;

        public AuthenticationService(IAccountRepository accountRepository, JwtSettings jwtSettings) : base(accountRepository)
        {
            _jwtSettings = jwtSettings;
            _accountRepository = accountRepository;
        }

        private Claim[] GenerateClaims(AccountDto accountDto)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub,_jwtSettings.Subject),
                new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Iat,DateTime.UtcNow.ToString()),
                new Claim("Id",accountDto.Id.ToString()),
                new Claim("FullName",accountDto.FullName),
                new Claim("Email",accountDto.Email),
                new Claim(ClaimTypes.Role, "User")
            };

            return claims;
        }

        private JwtSecurityToken GenerateJWT(AccountDto accountDto)
        {
            var claims = GenerateClaims(accountDto);

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(_jwtSettings.Issuer, _jwtSettings.Audience, claims, expires: DateTime.UtcNow.AddDays(1), signingCredentials: signIn);

            return token;
        }

        public async Task<string> AuthenticateAccountAsync(string email, string password)
        {
            AccountDto accountDto = await _accountRepository.GetAccountWithEmailAsync(email);
            if (accountDto == null || accountDto.IsDeleted)
            {
                throw new KeyNotFoundException();
            }
            else if (!BCrypt.Net.BCrypt.Verify(password, accountDto.Password))
            {
                throw new ArgumentException();
            }

            JwtSecurityToken token = GenerateJWT(accountDto);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
