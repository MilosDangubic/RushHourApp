﻿using Microsoft.AspNetCore.Mvc;
using Prime.RushHour.Domain.Dtos.Requests;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using Microsoft.AspNetCore.Authorization;

namespace Prime.RushHour.API.Controllers
{
    [ApiController]
    [Route("api/account")]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }


        [HttpPut("{id}/email"), Authorize(Roles = "client,employee")]
        public async Task<IActionResult> UpdateEmail(Guid id, [FromBody] UpdateEmailRequest updateEmailRequest)
        {
            if (this.User.FindFirst("Id").Value != id.ToString())
            {
                return Forbid();
            }

            try
            {
                await _accountService.UpdateEmail(id, updateEmailRequest.Email);
                return NoContent();
            }
            catch (ArgumentException)
            {
                return BadRequest("New email already exist");
            }
            catch (KeyNotFoundException)
            {
                return NotFound("Missing account with given email");
            }
        }

        [HttpPut("{id}/password"), Authorize(Roles = "client,employee")]
        public async Task<IActionResult> UpdatePassword(Guid id, [FromBody] UpdatePasswordRequest updatePasswordRequest)
        {
            if (this.User.FindFirst("Id").Value != id.ToString())
            {
                return Forbid();
            }

            try
            {
                await _accountService.UpdatePassword(id, updatePasswordRequest.OldPassword, updatePasswordRequest.NewPassword);
                return Ok();
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
            catch (ArgumentException)
            {
                return BadRequest();
            }
        }

        [HttpGet("profile"), Authorize(Roles = "client,employee")]
        public async Task<IActionResult> GetByIdAsync()
        {
            try
            {
                AccountDto accountDto = await _accountService.GetByIdAsync(new Guid(this.User.FindFirst("Id").Value));
                return Ok(accountDto);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpDelete("{id}"), Authorize(Roles = "provider_administrator")]
        public  async Task<IActionResult> DeleteAsync(Guid id)
        {
            try
            {
                await _accountService.DeleteAsync(id);
                return Ok();
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpPut("{id}"), Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> UpdateAsync(Guid id, [FromBody] AccountDto accountDto)
        {
            if (this.User.FindFirst("Id").Value != id.ToString())
            {
                return Forbid();
            }

            await _accountService.UpdateAsync(id, accountDto);

            return Ok();
        }

        [HttpGet, Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> GetAllAsync([FromQuery] PageRequest pageRequest)
        {
            IEnumerable<AccountDto> accountsDto = await _accountService.GetAllAsync(pageRequest.PageNumber, pageRequest.PageSize);

            return Ok(accountsDto);
        }
    }
}
