﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using System.IdentityModel.Tokens.Jwt;
using Prime.RushHour.Domain.Dtos.Requests;
using Microsoft.AspNetCore.Authorization;

namespace Prime.RushHour.API.Controllers
{
    [Route("api/authentication")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IAccountService _userService;
        private readonly JwtSettings _jwtSettings;

        public AuthenticationController(IAuthenticationService authenticationService, IAccountService userService, JwtSettings jwtSettings)
        {
            _authenticationService = authenticationService;
            _jwtSettings = jwtSettings;
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> AuthenticateUserAsync(LoginRequest loginRequest)
        {
            try
            {
                string token = await _authenticationService.AuthenticateAccountAsync(loginRequest.Email, loginRequest.Password);
                return Ok(token);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
            catch (ArgumentException)
            {
                return BadRequest("Invalid credentials");
            }
        }

        [HttpPost("register")]
        public async Task<IActionResult> RegisterAsync([FromBody] AccountDto userDto)
        {
            try
            {
                await _userService.RegisterAsync(userDto);
                return Ok();
            }
            catch (KeyNotFoundException)
            {
                return BadRequest();
            }
        }
    }
}
