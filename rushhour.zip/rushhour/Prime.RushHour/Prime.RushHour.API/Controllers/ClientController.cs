﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Domain.Dtos.Requests;

namespace Prime.RushHour.API.Controllers
{
    [Route("api/client")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly IClientService _clientService;
        private readonly IMapper _mapper;

        public ClientController(IClientService clientService, IMapper mapper)
        {
            _clientService = clientService;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsync([FromBody] ClientDto clientDto)
        {
            await _clientService.CreateAsync(clientDto);

            return NoContent();
        }

        [HttpDelete("{id}"), Authorize(Roles = "client")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            if (this.User.FindFirst("Id").Value != id.ToString())
            {
                return Forbid();
            }

            try
            {
                await _clientService.DeleteAsync(id);
                return NoContent();
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }


        [HttpGet("{id}"), Authorize(Roles = "client")]
        public async Task<IActionResult> GetByIdAsync(Guid id)
        {
            if (this.User.FindFirst("Id").Value != id.ToString())
            {
                return Forbid();
            }

            try
            {
                ClientDto clientDto = await _clientService.GetByIdAsync(id);
                return Ok(clientDto);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpGet("{id}/info"), Authorize(Roles = "provider_administator")]
        public async Task<IActionResult> GetClientForProvider(Guid id)
        {
            try
            {
                ClientDto clientDto = await _clientService.GetByIdAsync(id);
                ClientAdministratorViewData clientAdministratorView = _mapper.Map<ClientAdministratorViewData>(clientDto);
                return Ok(clientAdministratorView);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpPut("{id}"), Authorize(Roles = "client")]
        public async Task<IActionResult> UpdateAsync(Guid id, [FromBody] ClientDto clientDto)
        {
            if (this.User.FindFirst("Id").Value != id.ToString())
            {
                return Forbid();
            }

            await _clientService.UpdateAsync(id, clientDto);

            return NoContent();
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync([FromQuery] PageRequest pageRequest)
        {
            IEnumerable<ClientDto> clients = await _clientService.GetAllAsync(pageRequest.PageNumber, pageRequest.PageSize);

            return Ok(clients);
        }
    }
}
