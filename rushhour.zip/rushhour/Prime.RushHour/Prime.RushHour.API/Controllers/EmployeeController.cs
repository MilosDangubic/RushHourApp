﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Domain.Dtos.Requests;

namespace Prime.RushHour.API.Controllers
{
    [Route("api/employee")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpPost, Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> CreateAsync([FromBody] EmployeeDto employeeDto)
        {
            await _employeeService.CreateAsync(employeeDto);
            return NoContent();
        }

        [HttpDelete("{id}"), Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            try
            {
                await _employeeService.DeleteAsync(id);
                return NoContent();
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpGet("{id}"), Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> GetByIdAsync(Guid id)
        {
            try
            {
                EmployeeDto employeeDto = await _employeeService.GetByIdAsync(id);
                return Ok(employeeDto);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpPut("{id}"), Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> UpdateAsync(Guid id, [FromBody] EmployeeDto employeeDto)
        {
            await _employeeService.UpdateAsync(id, employeeDto);

            return NoContent();

        }

        [HttpGet, Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> GetAllAsync([FromQuery] PageRequest pageRequest)
        {
            IEnumerable<EmployeeDto> employees = await _employeeService.GetAllAsync(pageRequest.PageNumber, pageRequest.PageSize);

            return Ok(employees);
        }

        [HttpGet("profile"), Authorize(Roles = "employee")]
        public async Task<IActionResult> GetProfile()
        {
            try
            {
                EmployeeDto employeeDto = await _employeeService.GetByIdAsync(new Guid(this.User.FindFirst("Id").Value));
                return Ok(employeeDto);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpPut("profile"), Authorize(Roles = "emoloyee")]
        public async Task<IActionResult> UpdateProfile([FromBody] EmployeeDto employeeDto)
        {
            await _employeeService.UpdateAsync(new Guid(this.User.FindFirst("Id").Value), employeeDto);

            return NoContent();
        }
    }
}
