﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Prime.RushHour.Domain.Core.Services;
using Prime.RushHour.Domain.Dtos;
using Prime.RushHour.Domain.Dtos.Requests;

namespace Prime.RushHour.API.Controllers
{
    [Route("api/provider")]
    [ApiController]
    public class ProviderController : ControllerBase
    {
        private readonly IProviderService _providerService;
        private readonly IMapper _mapper;

        public ProviderController(IProviderService providerService, IMapper mapper)
        {
            _providerService = providerService;
            _mapper = mapper;
        }

        [HttpPost, Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> CreateAsync([FromBody] ProviderDto providerDto)
        {
            await _providerService.CreateAsync(providerDto);

            return NoContent();
        }

        [HttpDelete("{id}"), Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            try
            {
                await _providerService.DeleteAsync(id);
                return NoContent();
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpGet("{id}"), Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> GetByIdAsync(Guid id)
        {
            try
            {
                ProviderDto providerDto = await _providerService.GetByIdAsync(id);
                return Ok(providerDto);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpGet("{id}/info"), Authorize(Roles = "client")]
        public async Task<IActionResult> GetProviderForClient(Guid id)
        {
            try
            {
                ProviderDto providerDto = await _providerService.GetByIdAsync(id);
                ProviderClientViewData providerClientView = _mapper.Map<ProviderClientViewData>(providerDto);
                return Ok(providerClientView);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [HttpPut("{id}"), Authorize(Roles = "provider_administrator")]
        public async Task<IActionResult> UpdateAsync(Guid id, [FromBody] ProviderDto providerDto)
        {
            await _providerService.UpdateAsync(id, providerDto);

            return NoContent();
        }

        [HttpGet, Authorize(Roles = "provider_administrator,client")]
        public async Task<IActionResult> GetAllAsync([FromQuery] PageRequest pageRequest)
        {
            IEnumerable<ProviderDto> providers = await _providerService.GetAllAsync(pageRequest.PageNumber, pageRequest.PageSize);

            return Ok(providers);
        }
    }
}
