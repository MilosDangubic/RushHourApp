﻿using Prime.RushHour.Data.Models;
using Prime.RushHour.Domain.Dtos;
using AutoMapper;
namespace Prime.RushHour.API.Mapper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<AccountDto, Account>().ReverseMap();
            CreateMap<ProviderDto,Provider>().ReverseMap();
            CreateMap<ClientDto,Client>().ReverseMap();
            CreateMap<EmployeeDto, Employee>().ReverseMap();
            CreateMap<RoleDto, Role>().ReverseMap();
            CreateMap<ClientDto, ClientAdministratorViewData>().ReverseMap();
        }
    }
}
