﻿using FluentValidation;
using FluentValidation.Validators;
using System.Text.RegularExpressions;

namespace Prime.RushHour.API.Validators
{
    public class PhoneValidator<T> : PropertyValidator<T, string>
    {
        public override string Name => "PhoneNumberValidator";
        private readonly string _phonePattern = @"^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$";

        public override bool IsValid(ValidationContext<T> context, string value)
        {
            if(!Regex.IsMatch(value, _phonePattern)) 
            {
                return false;
            }

            if(value.Length < 10 || value.Length > 20) 
            {
                return false;
            }

            if (string.IsNullOrEmpty(value)) 
            {
                return false;
            }

            return true;
        }

        protected override string GetDefaultMessageTemplate(string errorCode)
        => "{PropertyName} must be valid phone number.";
    }
}
