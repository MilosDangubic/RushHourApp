﻿using FluentValidation;
using Prime.RushHour.Domain.Dtos;

namespace Prime.RushHour.API.Validators
{
    public class EmployeeValidator : AbstractValidator<EmployeeDto>
    {
        public EmployeeValidator()
        {
            RuleFor(e => e.Title)
                .Matches(@"^[0-9a-zA-Z ]+$")
                .WithMessage("Numbers and letters only please.");

            RuleFor(e => e.Phone).SetValidator(new PhoneValidator<EmployeeDto>());
            RuleFor(e => e.RatePerHour).NotNull().GreaterThan(0);
        }
    }
}
