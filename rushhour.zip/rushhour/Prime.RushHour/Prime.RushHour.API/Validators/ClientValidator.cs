﻿using FluentValidation;
using Prime.RushHour.Domain.Dtos;

namespace Prime.RushHour.API.Validators
{
    public class ClientValidator : AbstractValidator<ClientDto>
    {
        public ClientValidator() 
        {
            RuleFor(c => c.Address).NotNull().MinimumLength(3);
            RuleFor(c => c.Phone).SetValidator(new PhoneValidator<ClientDto>());
        }
    }
}
