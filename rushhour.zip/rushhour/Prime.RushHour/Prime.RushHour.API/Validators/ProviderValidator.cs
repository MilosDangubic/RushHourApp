﻿using FluentValidation;
using Prime.RushHour.Data.Models;
using Prime.RushHour.Domain.Dtos;

namespace Prime.RushHour.API.Validators
{
    public class ProviderValidator : AbstractValidator<ProviderDto>
    {
        public ProviderValidator()
        {
            RuleFor(p => p.IsDeleted).NotNull();
            RuleFor(p => p.Name).NotNull().MinimumLength(3);
            RuleFor(p => p.Website).Must(uri => Uri.TryCreate(uri, UriKind.Absolute, out _)).When(p => !string.IsNullOrEmpty(p.Website));
            RuleFor(p => p.BusinessDomain).MinimumLength(2).Matches(@"^[a-zA-Z]+$");
            RuleFor(p => p.Phone).SetValidator(new PhoneValidator<ProviderDto>());
            RuleFor(p => p.WorkingDayStart).NotNull();
            RuleFor(p => p.WorkingDayEnd).NotNull();
            RuleFor(p => p.WorkingDays).NotNull();
        }
    }
}
