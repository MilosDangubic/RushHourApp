﻿using FluentValidation;
using Prime.RushHour.Domain.Dtos.Requests;

namespace Prime.RushHour.API.Validators
{
    public class EmailValidator : AbstractValidator<UpdateEmailRequest>
    {
        public EmailValidator() 
        {
            RuleFor(e => e.Email).NotEmpty().EmailAddress();
        }
    }
}
