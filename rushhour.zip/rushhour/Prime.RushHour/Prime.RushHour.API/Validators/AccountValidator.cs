﻿using FluentValidation;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.API.Validators
{
    public class AccountValidator : AbstractValidator<AccountDto>
    {
        public AccountValidator() 
        {
            RuleFor(u => u.IsDeleted).NotNull();
            RuleFor(u => u.Email).NotEmpty().EmailAddress();
            RuleFor(u => u.FullName).NotEmpty().MinimumLength(3).Matches(@"^[a-zA-Z][a-zA-Z0-9-'\s]+$");
            RuleFor(u => u.Password).NotEmpty().Matches(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$");
        }
    }
}
