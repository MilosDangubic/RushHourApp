﻿using FluentValidation;
using Prime.RushHour.Domain.Dtos;

namespace Prime.RushHour.API.Validators
{
    public class RoleValidator : AbstractValidator<RoleDto>
    {
        public RoleValidator() 
        {
            RuleFor(r => r.Name).NotNull()
                .MinimumLength(3)
                .Matches(@"^[a-zA-Z0-9_]*$");
        }
    }
}
