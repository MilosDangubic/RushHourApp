﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Prime.RushHour.Data.Models;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Repositories
{
    public class AccountRepository : BaseRepository<Account>, IAccountRepository
    {
        public AccountRepository(RushHourContext applicationContext, IMapper mapper) : base(applicationContext, mapper)
        {
        }

        public async Task<AccountDto> GetAccountWithEmailAsync(string email)
        {
            Account account = await Items.Where(x => x.Email == email && !x.IsDeleted).FirstOrDefaultAsync();
            return Mapper.Map<AccountDto>(account);
        }

        public async Task<bool> UpdateEmail(Guid id, string email)
        {
            Account account = await Items.Where(x => x.Id == id).FirstOrDefaultAsync();

            if (account == null)
            {
                return false;
            }

            account.Email = email;
            await RushHourContext.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UpdatePassword(Guid id, string password)
        {
            Account account = await Items.Where(x => x.Id == id).FirstOrDefaultAsync();

            if (account == null)
            {
                return false;
            }

            account.Password = password;
            await RushHourContext.SaveChangesAsync();

            return true;
        }

        public override async Task<bool> DeleteAsync(Guid id)
        {
            var entity = await Items.FirstOrDefaultAsync(x => x.Id == id);

            if (entity != null)
            {
                entity.IsDeleted = true;
                await RushHourContext.SaveChangesAsync();

                return true;
            }

            return false;
        }
    }
}
