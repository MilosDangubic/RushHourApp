﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Prime.RushHour.Data.Extensions;
using Prime.RushHour.Data.Models;
using Prime.RushHour.Domain.Core.Repositories;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Repositories
{
    public class BaseRepository<TEntity> : IBaseRepository where TEntity : Entity
    {
        protected IMapper Mapper { get; }
        protected RushHourContext RushHourContext { get; }
        protected DbSet<TEntity> Items { get; }

        public BaseRepository(RushHourContext applicationContext, IMapper mapper)
        {
            RushHourContext = applicationContext;
            Mapper = mapper;
            Items = RushHourContext.Set<TEntity>();
        }

        public async Task<TDto> CreateAsync<TDto>(TDto tDto)
        {
            var entity = Mapper.Map<TEntity>(tDto);

            await Items.AddAsync(entity);
            await RushHourContext.SaveChangesAsync();

            return Mapper.Map<TDto>(entity);
        }

        public virtual async Task<bool> DeleteAsync(Guid id)
        {
            var entity = await Items
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted);

            if (entity != null)
            {
                Items.Remove(entity);
                await RushHourContext.SaveChangesAsync();
                return true;
            }

            return false;
        }

        public async Task<IEnumerable<TDto>> GetAllAsync<TDto>(int pageNumber, int pageSize)
        {
            PaginatedList<TEntity> entities = new PaginatedList<TEntity>();
            await entities.CreateAsync<TEntity>(Items.AsNoTracking(), pageNumber, pageSize);

            List<TDto> entitiesDto = new List<TDto>();
            foreach (TEntity entity in entities)
            {
                entitiesDto.Add(Mapper.Map<TDto>(entity));
            }

            return entitiesDto;
        }

        public async Task<TDto> GetByIdAsync<TDto>(Guid id)
        => Mapper.Map<TDto>(await Items.FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted));

        public async Task UpdateAsync<TDto>(TDto tDto)
        {
            TEntity entity = Mapper.Map<TEntity>(tDto);

            RushHourContext.Set<TEntity>().Update(entity);
            await RushHourContext.SaveChangesAsync();
        }
    }
}
