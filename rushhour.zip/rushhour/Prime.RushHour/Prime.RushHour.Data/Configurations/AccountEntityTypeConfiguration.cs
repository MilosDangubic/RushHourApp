﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Prime.RushHour.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Configurations
{
    public class AccountEntityTypeConfiguration : IEntityTypeConfiguration<Account>
    {
        public void Configure(EntityTypeBuilder<Account> builder)
        {
            builder.HasKey(a => a.Id);

            builder.Property(a => a.Email).IsRequired().HasMaxLength(150);
            builder.HasIndex(a => a.Email).IsUnique();

            builder.Property(a => a.FullName).IsRequired().HasMaxLength(150);

            builder.Property(a => a.Password).IsRequired().HasMaxLength(150);

            builder.HasOne(a => a.Empolyee)
                .WithOne(e => e.Account)
                .HasForeignKey<Employee>(e => e.AccountId)
                .IsRequired();

            builder.HasOne(a => a.Client)
                .WithOne(c => c.Account)
                .HasForeignKey<Client>(c => c.AccountId)
                .IsRequired();

            builder.HasOne(a => a.Role)
                .WithMany(r => r.Accounts)
                .HasForeignKey(a => a.RoleId)
                .IsRequired();
        }
    }
}
