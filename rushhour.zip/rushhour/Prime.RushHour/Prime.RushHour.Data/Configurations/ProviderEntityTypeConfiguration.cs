﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Prime.RushHour.Data.Converters;
using Prime.RushHour.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Configurations
{
    public class ProviderEntityTypeConfiguration : IEntityTypeConfiguration<Provider>
    {
        public void Configure(EntityTypeBuilder<Provider> builder)
        {
            builder.HasKey(p => p.Id);

            builder.Property(p => p.Name).IsRequired();
            builder.HasIndex(p => p.Name).IsUnique();

            builder.Property(p => p.Website).IsRequired();

            builder.Property(p => p.BusinessDomain).IsRequired();

            builder.Property(p => p.Phone).IsRequired();

            builder.Property(p => p.WorkingDayStart).IsRequired();

            builder.Property(p => p.WorkingDayEnd).IsRequired();

            var workingDaysConverter = new WorkingDaysConvertror();

            var valueComparer = new ValueComparer<ICollection<DayOfWeek>>(
                (c1, c2) => c1.SequenceEqual(c2),
                c => c.Aggregate(0, (a, v) => HashCode.Combine(a, v.GetHashCode())),
                c => (ICollection<DayOfWeek>)c.ToList());

            builder.Property(p => p.WorkingDays)
              .IsRequired()
              .HasConversion(workingDaysConverter)
              .Metadata.SetValueComparer(valueComparer);
        }
    }
}
