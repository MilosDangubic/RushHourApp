﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Converters
{
    public class WorkingDaysConvertror : ValueConverter<ICollection<DayOfWeek>, string>
    {

        public WorkingDaysConvertror()
            : base
            (
                wd => string.Join(";", wd.ToArray()),
                str => new List<DayOfWeek>
                (
                    str.Split
                    (
                        new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries
                    )
                    .Select(x => (DayOfWeek)Convert.ToInt32(x))
                )
            )
        {
        }
    }
}
