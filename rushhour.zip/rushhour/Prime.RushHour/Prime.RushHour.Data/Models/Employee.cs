﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Models
{
    public class Employee : Entity
    {
        public string Title { get; set; }

        public string Phone { get; set; }

        public float RatePerHour { get; set; }

        public virtual Provider Provider { get; set; }

        public Guid ProviderId { get; set; }

        public virtual Account Account { get; set; }

        public Guid AccountId { get; set; }
    }
}
