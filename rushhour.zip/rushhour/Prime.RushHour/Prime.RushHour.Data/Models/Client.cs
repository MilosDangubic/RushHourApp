﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Models
{
    public class Client : Entity
    {
        public string Phone { get; set; }

        public string Address { get; set; }

        public virtual Account Account { get; set; }

        public Guid AccountId { get; set; }
    }
}
