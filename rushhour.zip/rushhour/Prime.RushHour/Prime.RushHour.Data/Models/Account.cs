﻿using Prime.RushHour.Domain.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Models
{
    public class Account : Entity
    {
        public string Email { get; set; }

        public string Password { get; set; }

        public string FullName { get; set; }

        public virtual Employee Empolyee { get; set; }

        public virtual Client Client { get; set; }

        public virtual Role Role { get; set; }

        public Guid RoleId { get; set; }
    }
}
