﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Models
{
    public class Provider : Entity
    {
        public string Name { get; set; }

        public string Website { get; set; }

        public string BusinessDomain { get; set; }

        public string Phone { get; set; }

        public ICollection<DayOfWeek> WorkingDays { get; set; }
        public TimeSpan WorkingDayStart { get; set; }

        public TimeSpan WorkingDayEnd { get; set; }

        public ICollection<Employee> Employees { get; set; }
    }
}
