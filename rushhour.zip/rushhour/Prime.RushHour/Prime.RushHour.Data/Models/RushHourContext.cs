﻿using Microsoft.EntityFrameworkCore;
using Prime.RushHour.Data.Configurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Models
{
    public class RushHourContext : DbContext
    {
        public RushHourContext(DbContextOptions options) : base(options)
        {

        }

        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<Provider> Providers { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Client> Clients { get; set; }
        public virtual DbSet<Role> Roles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            new AccountEntityTypeConfiguration().Configure(modelBuilder.Entity<Account>());
            new ProviderEntityTypeConfiguration().Configure(modelBuilder.Entity<Provider>());
            new EmployeeEntityTypeConfiguration().Configure(modelBuilder.Entity<Employee>());
            new ClientEntityTypeConfiguration().Configure(modelBuilder.Entity<Client>());
            new RoleEntityTypeConfiguration().Configure(modelBuilder.Entity<Role>());

            modelBuilder.Entity<Account>().HasQueryFilter(u => !u.IsDeleted);
            modelBuilder.Entity<Provider>().HasQueryFilter(p => !p.IsDeleted);
            modelBuilder.Entity<Employee>().HasQueryFilter(e => !e.IsDeleted);
            modelBuilder.Entity<Client>().HasQueryFilter(c => !c.IsDeleted);
            modelBuilder.Entity<Role>().HasQueryFilter(r => !r.IsDeleted);
        }
    }
}
