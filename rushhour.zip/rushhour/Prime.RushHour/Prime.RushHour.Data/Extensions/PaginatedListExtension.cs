﻿using Microsoft.EntityFrameworkCore;
using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Data.Extensions
{
    public static class PaginatedListExtension
    {
        public static async Task CreateAsync<T>(this PaginatedList<T> paginatedList, IQueryable<T> source, int pageIndex, int pageSize)
        {
            var count = await source.CountAsync();
            var items = await source.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToListAsync();

            paginatedList.AddRange(items);
            paginatedList.PageIndex = pageIndex;
            paginatedList.TotalPages = (int)Math.Ceiling(count / (double)pageSize);
        }
    }
}
