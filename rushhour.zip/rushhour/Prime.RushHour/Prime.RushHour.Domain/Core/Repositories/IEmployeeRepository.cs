﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Core.Repositories
{
    public interface IEmployeeRepository : IBaseRepository
    {
    }
}
