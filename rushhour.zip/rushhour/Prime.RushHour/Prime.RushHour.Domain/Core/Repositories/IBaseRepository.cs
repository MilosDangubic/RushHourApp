﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Core.Repositories
{
    public interface IBaseRepository
    {
        Task<TDto> GetByIdAsync<TDto>(Guid id);
        Task<IEnumerable<TDto>> GetAllAsync<TDto>(int pageNumber, int pageSize);
        Task<TDto> CreateAsync<TDto>(TDto tDto);
        Task<bool> DeleteAsync(Guid id);
        Task UpdateAsync<TDto>(TDto tDto);
    }
}
