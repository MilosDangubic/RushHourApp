﻿using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Core.Repositories
{
    public interface IAccountRepository : IBaseRepository
    {
        public Task<AccountDto> GetAccountWithEmailAsync(string email);
        public Task<bool> UpdatePassword(Guid id, string password);
        public Task<bool> UpdateEmail(Guid id, string email);
    }
}
