﻿using Prime.RushHour.Domain.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Core.Services
{
    public interface IAccountService : IBaseService<AccountDto>
    {
        public Task<AccountDto> GetAccountWithEmailAsync(string email);
        public Task RegisterAsync(AccountDto userDto);
        public Task UpdatePassword(Guid id, string oldPassword, string newPassword);
        public Task UpdateEmail(Guid id, string email);

    }
}
