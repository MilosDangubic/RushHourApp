﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Core.Services
{
    public interface IBaseService<TDto>
    {
        Task<TDto> GetByIdAsync(Guid id);
        Task<IEnumerable<TDto>> GetAllAsync(int? pageNumber, int? pageSize);
        Task CreateAsync(TDto tDto);
        Task DeleteAsync(Guid id);
        Task UpdateAsync(Guid id, TDto tDto);
    }
}
