﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Dtos
{
    public class ProviderDto : BaseDto
    {
        public string Name { get; set; }

        public string Website { get; set; }

        public string BusinessDomain { get; set; }

        public string Phone { get; set; }

        public ICollection<DayOfWeek> WorkingDays { get; set; }

        public TimeSpan WorkingDayStart { get; set; }

        public TimeSpan WorkingDayEnd { get; set; }
    }
}
