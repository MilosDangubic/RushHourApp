﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Dtos
{
    public class PaginatedList<T> : List<T>
    {
        public const int maxPageSize = 30;
        public int PageIndex { get;  set; }
        public int TotalPages { get;  set; }

        public PaginatedList() 
        {
        }
        public PaginatedList(List<T> items, int count, int pageIndex, int pageSize)
        {
            PageIndex = pageIndex;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);

            this.AddRange(items);
        }

        public bool HasPreviousPage => PageIndex > 1;
        public bool HasNextPage => PageIndex < TotalPages;
    }
}
