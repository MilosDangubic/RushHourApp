﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prime.RushHour.Domain.Dtos
{
    public class EmployeeDto : BaseDto
    {
        public string Title { get; set; }

        public string Phone { get; set; }

        public float RatePerHour { get; set; }
    }
}
